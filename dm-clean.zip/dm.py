"""
TAHAP 4 (final) — Download manager yang benar-benar dipakai.

Yang ditambahkan dibanding tahap 3:
  - RETRY dengan exponential backoff  : 429 / 5xx / koneksi reset tidak mematikan download
  - PROGRESS BAR agregat              : tahu kecepatan & sisa waktu
  - Ctrl+C aman                       : file .part tetap ada, jalankan lagi = lanjut
  - EXCEPTION tidak hilang diam-diam  : error tiap part dicatat

Pemakaian:
    python dm.py <URL> [-o nama_file] [-c 8] [--no-resume]

Contoh:
    python dm.py https://proof.ovh.net/files/100Mb.dat -o film.bin -c 8
"""
import argparse
import json
import os
import sys
import threading
import time
import urllib.error
import urllib.request

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) dm.py/1.0"}
CHUNK = 256 * 1024
RETRY_MAKS = 6
STOP = threading.Event()


def _nama_aman(s: str) -> str:
    """Bersihkan nama file: buang path traversal, karakter ilegal Windows."""
    import re as _re
    s = s.replace("\\", "/").split("/")[-1]
    s = _re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", s)
    s = s.strip(" .")
    if s in ("", ".", ".."):
        return "download.bin"
    if s.upper().split(".")[0] in {"CON", "PRN", "AUX", "NUL"}:
        s = "_" + s
    return s[:150] or "download.bin"


def probe(url):
    """Ukuran + dukungan Range + saran nama file. Ikut redirect (urllib otomatis)."""
    req = urllib.request.Request(url, method="HEAD", headers=UA)
    with urllib.request.urlopen(req, timeout=30) as r:
        size = r.headers.get("Content-Length")
        ranges = (r.headers.get("Accept-Ranges") or "none").lower()
        final = r.geturl()
        nama = _nama_dari_header(r.headers, final)
    if size is None:
        raise SystemExit("Server tidak mengirim Content-Length — tidak bisa disegmentasi.")
    if ranges != "bytes":
        raise SystemExit(f"Server tidak mendukung Range (Accept-Ranges: {ranges}).")
    return int(size), final, nama


def _nama_dari_header(headers, final_url):
    """Tentukan nama file dari 3 sumber, dalam urutan prioritas:
    1. Content-Disposition header
    2. query param ?name= (contoh: berkasdrive.com)
    3. basename dari path URL
    """
    import re as _re
    from urllib.parse import urlparse, parse_qs, unquote
    cd = headers.get("Content-Disposition") or ""
    m = _re.search(r'filename\*?=(["\']?)([^;\s]+)\1', cd, _re.I)
    if m:
        return unquote(m.group(2).strip())
    qs = parse_qs(urlparse(final_url).query)
    if "name" in qs:
        return unquote(qs["name"][0])
    path_nama = unquote(os.path.basename(urlparse(final_url).path))
    return path_nama if path_nama and "." in path_nama else "download.bin"


def bagi(size, n):
    """Bagi size jadi n segmen. Sisa pembagian masuk ke segmen terakhir."""
    potong = size // n
    out = []
    for i in range(n):
        s = i * potong
        e = size - 1 if i == n - 1 else s + potong - 1
        out.append({"idx": i, "start": s, "end": e, "selesai": False})
    return out


def ambil_part(url, seg, target, state, lock):
    """Download satu segmen. Resume dari ukuran file saat ini. Retry kalau gagal."""
    nama = f"{target}.part{seg['idx']}"
    perlu = seg["end"] - seg["start"] + 1

    for percobaan in range(1, RETRY_MAKS + 1):
        if STOP.is_set():
            return
        sudah = os.path.getsize(nama) if os.path.exists(nama) else 0
        if sudah >= perlu:
            seg["selesai"] = True
            return
        if sudah:
            state["dari_disk"] += 0        # sudah ada di disk, bukan traffic baru

        mulai = seg["start"] + sudah
        try:
            req = urllib.request.Request(
                url, headers={**UA, "Range": f"bytes={mulai}-{seg['end']}"})
            with urllib.request.urlopen(req, timeout=60) as r:
                if r.status != 206:
                    raise RuntimeError(f"status {r.status}, bukan 206")
                with open(nama, "ab") as f:
                    while not STOP.is_set():
                        c = r.read(CHUNK)
                        if not c:
                            break
                        f.write(c)
                        with lock:
                            state["bytes"] += len(c)
            # kalau keluar loop tanpa STOP, cek apakah benar-benar penuh
            if os.path.getsize(nama) >= perlu:
                seg["selesai"] = True
                return
        except (urllib.error.HTTPError, urllib.error.URLError,
                ConnectionResetError, TimeoutError, RuntimeError, OSError) as e:
            kode = getattr(e, "code", None)
            # 416 = range tidak valid, biasanya artinya sudah selesai
            if kode == 416:
                seg["selesai"] = os.path.getsize(nama) >= perlu
                return
            if percobaan == RETRY_MAKS:
                with lock:
                    state["gagal"].append(f"part{seg['idx']}: {type(e).__name__} {e}")
                return
            jeda = min(2 ** percobaan, 20)
            if kode == 429:
                jeda = max(jeda, 5)
            time.sleep(jeda)


def tampil(state, total, mulai, lock, jumlah_part):
    """Progress bar agregat. Hanya redraw kalau angkanya berubah (hemat output)."""
    terakhir = -1
    while not state["selesai_semua"].is_set():
        with lock:
            b = state["bytes"]
        if b == terakhir:
            time.sleep(0.2)
            continue
        terakhir = b
        lewat = time.time() - mulai
        laju = b / lewat if lewat > 0 else 0
        persen = min(b / total * 100, 100) if total else 0
        lebar = 28
        isi = "#" * int(lebar * persen / 100)
        sisa = (total - b) / laju if laju > 0 else 0
        sys.stdout.write(
            f"\r[{isi:<{lebar}}] {persen:5.1f}%  "
            f"{b/1e6:7.2f}/{total/1e6:.2f} MB  "
            f"{laju/1e6:6.2f} MB/s  sisa {int(sisa)//60}m{int(sisa)%60:02d}s")
        sys.stdout.flush()
        time.sleep(0.2)


def gabung(target, segmen):
    with open(target, "wb") as fout:
        for s in segmen:
            p = f"{target}.part{s['idx']}"
            with open(p, "rb") as fp:
                while True:
                    b = fp.read(1 << 20)
                    if not b:
                        break
                    fout.write(b)
            os.remove(p)


def main():
    ap = argparse.ArgumentParser(description="Download manager segmented + resume")
    ap.add_argument("url")
    ap.add_argument("-o", "--output", default=None)
    ap.add_argument("-c", "--connections", type=int, default=8)
    ap.add_argument("--no-resume", action="store_true")
    a = ap.parse_args()

    size, url_akhir, nama_saran = probe(a.url)
    target = a.output or _nama_aman(nama_saran) or "download.bin"
    meta_path = target + ".dm.json"

    if a.no_resume:
        for f in list(os.listdir(".")):
            if f.startswith(target + ".part"):
                os.remove(f)
        if os.path.exists(meta_path):
            os.remove(meta_path)

    # muat / buat rencana
    if os.path.exists(meta_path):
        meta = json.load(open(meta_path))
        if meta["size"] != size or meta["url"] != a.url:
            print("!! meta tidak cocok (URL/ukuran berubah) — mulai ulang")
            for f in list(os.listdir(".")):
                if f.startswith(target + ".part"):
                    os.remove(f)
            meta = None
        else:
            sudah = sum(os.path.getsize(f"{target}.part{s['idx']}")
                        for s in meta["segmen"] if os.path.exists(f"{target}.part{s['idx']}"))
            print(f">> RESUME: {sudah/1e6:.2f} MB sudah ada di disk dari {size/1e6:.2f} MB")
    else:
        meta = None

    if meta is None:
        meta = {"url": a.url, "size": size, "target": target,
                "segmen": bagi(size, a.connections)}
        json.dump(meta, open(meta_path, "w"), indent=2)
        print(f">> BARU: {size/1e6:.2f} MB, {a.connections} segmen")
        sudah = 0

    segmen = meta["segmen"]
    state = {"bytes": 0, "gagal": [], "dari_disk": 0, "selesai_semua": threading.Event()}
    lock = threading.Lock()

    # hitung byte yang sudah ada supaya progress bar jujur
    for s in segmen:
        p = f"{target}.part{s['idx']}"
        if os.path.exists(p):
            state["bytes"] += os.path.getsize(p)

    t0 = time.time()
    ts = [threading.Thread(target=ambil_part,
                           args=(a.url, s, target, state, lock), daemon=True)
          for s in segmen]
    for t in ts:
        t.start()

    pengawas = threading.Thread(target=tampil,
                               args=(state, size, t0, lock, len(segmen)), daemon=True)
    pengawas.start()

    try:
        for t in ts:
            while t.is_alive():
                t.join(0.3)
    except KeyboardInterrupt:
        print("\n\n!! dihentikan. File .part disimpan — jalankan perintah yang sama untuk lanjut.")
        STOP.set()
        state["selesai_semua"].set()
        sys.exit(130)

    state["selesai_semua"].set()
    time.sleep(0.3)
    print()

    if state["gagal"]:
        print("ada part yang gagal:")
        for g in state["gagal"]:
            print("   ", g)
        print("jalankan lagi — part yang sudah lengkap tidak diunduh ulang.")
        return

    semua_ada = all(os.path.getsize(f"{target}.part{s['idx']}") ==
                    s["end"] - s["start"] + 1 for s in segmen)
    if not semua_ada:
        print("belum lengkap, jalankan lagi untuk melanjutkan.")
        return

    gabung(target, segmen)
    os.remove(meta_path)
    akhr = os.path.getsize(target)
    dur = time.time() - t0
    print(f"selesai: {akhr/1e6:.2f} MB dalam {dur:.1f}s "
          f"({akhr/1e6/max(dur,0.01):.2f} MB/s)")
    print(f"utuh: {akhr == size}  ->  {os.path.abspath(target)}")


if __name__ == "__main__":
    main()
