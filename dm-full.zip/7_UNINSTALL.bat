@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Hapus / Uninstall DM Local
:: Target: folder ini (atau argumen pertama bila diberi)
set "TARGET=%~1"
if not defined TARGET set "TARGET=%~dp0"
for %%F in ("%TARGET%.") do set "TARGET=%%~fF"
set "JOB=%TEMP%\dm_hapus_%RANDOM%.bat"
echo.
echo  =======================================
echo   DM Local - Uninstall (Hapus Semua)
echo  =======================================
echo  Target folder:
echo     %TARGET%
echo.
echo  [1/3] Hentikan server DM Local (port 8787)...
taskkill /F /FI "WINDOWTITLE eq DM Server*" >nul 2>&1
if exist 3_TUTUP_SERVER.bat echo.|3_TUTUP_SERVER.bat >nul 2>&1
echo     selesai.
echo.
echo  [2/3] Hapus semua isi folder ini
echo     (python / tools / extension / downloads)...
echo     Jendela ini akan tertutup. Penghapusan
echo     lengkap berjalan 3 detik kemudian.
> "%JOB%" (
  echo @echo off
  echo cd /d %SystemRoot%\System32
  echo timeout /t 3 ^>nul
  echo rmdir /s /q "%TARGET%"
)
start "" "%JOB%"
echo.
echo  [3/3] Pembersihan Chrome (manual, sekali klik):
echo     Buka  chrome://extensions
echo     Klik "Hapus" pada kartu "DM Local" (bukan non-aktif).
echo.
echo  Sampai jumpa - terima kasih sudah coba DM Local.
timeout /t 3 /nobreak >nul
endlocal
exit
