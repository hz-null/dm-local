#!/usr/bin/env python3
"""Buka folder download di Explorer — langsung dari command line."""
import os, subprocess, sys
folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), "downloads")
if not os.path.isdir(folder):
    os.makedirs(folder, exist_ok=True)
subprocess.Popen(["explorer", folder])
print(f"Buka folder: {folder}")
