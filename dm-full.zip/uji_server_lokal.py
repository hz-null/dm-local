"""
uji_server_lokal.py — server HTTP uji yang mendukung Range, untuk menguji dm_server
tanpa bergantung pada internet (OVH/Hetzner sering memblokir kalau dipakai berulang).

Menyajikan file uji yang dibuat sendiri, mendukung:
  - HEAD dengan Content-Length + Accept-Ranges: bytes
  - GET dengan Range -> 206 Partial Content
  - Mode "rewel" opsional untuk menguji retry: sesekali balas 429 / putus koneksi

Jalankan:
    python uji_server_lokal.py                 # port 8899, file 20 MB
    python uji_server_lokal.py -s 50 -r 0.15   # 50 MB, 15% request dibuat gagal
"""
import argparse
import hashlib
import os
import random
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DATA = b""
REWEL = 0.0
THROTTLE = 0.0        # byte/detik; 0 = tanpa batas
STATS = {"req": 0, "range": 0, "gagal": 0, "bytes": 0}
LOCK = threading.Lock()


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _rewel(self):
        """Balas 429 atau putus koneksi sesekali, untuk menguji retry."""
        if REWEL and random.random() < REWEL:
            with LOCK:
                STATS["gagal"] += 1
            if random.random() < 0.5:
                self.send_response(429)
                self.send_header("Content-Length", "0")
                self.end_headers()
                return True
            self.close_connection = True      # putus tanpa balasan
            return True
        return False

    def do_HEAD(self):
        with LOCK:
            STATS["req"] += 1
        if not self._path_ok():
            self.send_response(404)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(len(DATA)))
        self.send_header("Accept-Ranges", "bytes")
        self.end_headers()

    def _path_ok(self):
        """Hanya /uji.bin (boleh ada query) yang dilayani; sisanya 404.
        Penting agar uji error realistis — server sungguhan juga begitu."""
        dari = self.path.split("?")[0]
        return dari in ("/uji.bin", "/")

    def do_GET(self):
        with LOCK:
            STATS["req"] += 1
        if not self._path_ok():
            body = b"<html><body>404 Not Found</body></html>"
            self.send_response(404)
            self.send_header("Content-Type", "text/html")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if self._rewel():
            return

        rng = self.headers.get("Range")
        if rng and rng.startswith("bytes=") and "," not in rng:
            a, _, b = rng[6:].partition("-")
            start = int(a) if a else 0
            end = int(b) if b else len(DATA) - 1
            end = min(end, len(DATA) - 1)
            if start > end or start >= len(DATA):
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{len(DATA)}")
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            potong = DATA[start:end + 1]
            with LOCK:
                STATS["range"] += 1
                STATS["bytes"] += len(potong)
            self.send_response(206)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(len(potong)))
            self.send_header("Content-Range", f"bytes {start}-{end}/{len(DATA)}")
            self.send_header("Accept-Ranges", "bytes")
            self.end_headers()
            kirim_throttle(self, potong)
            return

        with LOCK:
            STATS["bytes"] += len(DATA)
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(len(DATA)))
        self.end_headers()
        kirim_throttle(self, DATA)


def kirim_throttle(handler, data):
    """Kirim data pelan-pelan, meniru jaringan lambat.

    Tanpa ini, uji dari localhost selesai dalam milidetik dan tombol
    Jeda/Lanjut tidak sempat diuji sama sekali.
    """
    if not THROTTLE:
        try:
            handler.wfile.write(data)
        except (ConnectionError, OSError):
            pass          # client memutus (mis. dm.py dijeda) -> abaikan
        return
    potong = max(int(THROTTLE / 20), 4096)      # ~20 potongan per detik
    for i in range(0, len(data), potong):
        try:
            handler.wfile.write(data[i:i + potong])
            handler.wfile.flush()
        except (ConnectionError, OSError):
            return    # client menutup koneksi saat jeda -> normal, jangan crash
        time.sleep(potong / THROTTLE)


def main():
    global DATA, REWEL, THROTTLE
    ap = argparse.ArgumentParser()
    ap.add_argument("-p", "--port", type=int, default=8899)
    ap.add_argument("-s", "--size-mb", type=int, default=20)
    ap.add_argument("-r", "--rewel", type=float, default=0.0)
    ap.add_argument("-t", "--throttle", type=float, default=0.0,
                    help="batas kecepatan MB/s (0 = tanpa batas)")
    ap.add_argument("--status", action="store_true")
    a = ap.parse_args()

    REWEL = a.rewel
    THROTTLE = a.throttle * 1e6
    n = a.size_mb * 1024 * 1024
    print(f"menyiapkan {n/1e6:.0f} MB data uji…")
    blok = hashlib.sha256(b"dm-uji").digest()
    DATA = (blok * (n // len(blok) + 1))[:n]
    print(f"sha256 file uji: {hashlib.sha256(DATA).hexdigest()}")

    srv = ThreadingHTTPServer(("127.0.0.1", a.port), H)
    print(f"server uji: http://127.0.0.1:{a.port}/uji.bin")
    print(f"mode rewel: {REWEL*100:.0f}% request dibuat gagal")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nstatistik:", STATS)


if __name__ == "__main__":
    main()
