// content.js — platform-specific video URL extractor
// Di-inject ke tab YouTube, TikTok, X/Twitter oleh content_scripts di manifest.json

const PLATFORM = (() => {
  const h = location.hostname;
  if (h.includes("youtube.com") || h.includes("youtu.be")) return "youtube";
  if (h.includes("tiktok.com")) return "tiktok";
  if (h.includes("twitter.com") || h.includes("x.com")) return "twitter";
  return null;
})();

if (!PLATFORM) {
  window.postMessage({ type: "DM_VIDEOS_READY", platform: null, videos: [] }, "*");
}

/* ================================================================
   YOUTUBE
   ============================================================ */
function extractYouTube() {
  const vids = [];
  const seen = new Set();

  function add(url, nama, quality) {
    if (!url || seen.has(url)) return;
    seen.add(url);
    vids.push({ url, nama: nama || "youtube-" + quality, quality });
  }

  // 1. ytInitialPlayerResponse (embedded di HTML, paling reliable)
  let pr = null;
  try { pr = window.ytInitialPlayerResponse; } catch (_) {}
  if (!pr) {
    const m = document.body.innerHTML.match(/ytInitialPlayerResponse\s*=\s*(\{.*?\});/);
    if (m) { try { pr = JSON.parse(m[1]); } catch (_) {} }
  }

  if (pr && pr.streamingData) {
    // Progressive formats (video+audio gabung, paling engganti playable)
    const formats = pr.streamingData.formats || [];
    formats.forEach((f, i) => {
      if (f.url) add(f.url, f.quality || `quality${i}`, f.quality || i);
      else if (f.signatureCipher || f.cipher) {
        try {
          const d = new URLSearchParams(f.signatureCipher || f.cipher);
          const s = d.get("s");
          if (s) {
            // Butuh ngetranslate s — YouTube signature cipher.
            // Untuk versi sederhana, biarkan aja (work di banyak kasus untuk stream publik)
            const url = d.get("url") + "&s=" + s;
            add(url, f.quality || `quality${i}`);
          }
        } catch (_) {}
      }
    });

    // DASH formats (video pisah dari audio)
    const adaptive = pr.streamingData.adaptiveFormats || [];
    adaptive.forEach((f) => {
      if (f.mimeType && f.mimeType.includes("video/mp4") && f.quality !== "tiny") {
        add(f.url || "", f.quality || "dash-video", f.quality || "dash");
      }
    });
  }

  // 2. DASH manifest (.mpd) — kadang ada di HTML
  const pageHtml = document.documentElement.innerHTML;
  const mpdMatch = pageHtml.match(/(https:\/\/[^"'\s<>]+\.mpd[^"'\s<>]*)/gi);
  if (mpdMatch) {
    mpdMatch.forEach((url) => {
      const cleanUrl = url.replace(/['";,]$/, "");
      add(cleanUrl, "dash-playlist.mpd", "mpd");
    });
  }

  // 3. <video> dan <source> tags langsung
  document.querySelectorAll("video[src]").forEach((v) => {
    add(v.src, "video-tag", "dom");
  });
  document.querySelectorAll("source[src]").forEach((s) => {
    add(s.src, "source-tag", "dom");
  });

  // 4. Scan script untuk googlevideo.com URLs (XHR dinamis sering ke sini)
  const scripts = document.querySelectorAll("script");
  scripts.forEach((script) => {
    if (!script.textContent) return;
    const urls = script.textContent.match(/https:\/\/[^"'\s<>]*googlevideo\.com[^"'\s<>]*/gi);
    if (urls) {
      urls.slice(0, 20).forEach((url) => {
        const cleanUrl = url.replace(/['";,]+$/, "");
        if (cleanUrl.includes("/videoplayback/")) return;
        if (cleanUrl.includes("itag=")) {
          add(cleanUrl, "xhr-video", "xhr");
        }
      });
    }
  });

  return vids;
}

/* ================================================================
   TIKTOK
   ============================================================ */
function extractTikTok() {
  const vids = [];
  const seen = new Set();

  function add(url, nama) {
    if (!url || seen.has(url)) return;
    seen.add(url);
    vids.push({ url, nama: nama || "tiktok-video", quality: "720p" });
  }

  // __NEXT_DATA__ JSON (bisa langsung di HTML)
  const nextDataScript = document.querySelector('script[id="__NEXT_DATA__"]');
  if (nextDataScript) {
    try {
      const data = JSON.parse(nextDataScript.textContent);
      const item = data?.props?.pageProps?.item;
      if (item && item.video) {
        if (item.video.downloadAddr) add(item.video.downloadAddr, "tiktok-download");
        if (item.video.playAddr) add(item.video.playAddr, "tiktok-play");
      } else {
        // Try aweme API structure
        const aweme = data?.props?.pageProps?.awemeInfo;
        if (aweme && aweme.video) {
          if (aweme.video.downloadAddr) add(aweme.video.downloadAddr, "tiktok-download");
          if (aweme.video.playAddr) add(aweme.video.playAddr, "tiktok-play");
        }
      }
    } catch (_) {}
  }

  // Scan page HTML untuk .mp4 URLs
  const html = document.documentElement.innerHTML;
  const mp4Matches = html.match(/https:\/\/[^"'\s<>]+\.mp4[^"'\s<>]*/gi);
  if (mp4Matches) {
    mp4Matches.slice(0, 10).forEach((url) => {
      const cleanUrl = url.replace(/['";,]+$/, "");
      add(cleanUrl, "tiktok-direct");
    });
  }

  // <video> dan <source> tags
  document.querySelectorAll("video[src]").forEach((v) => add(v.src, "tiktok-video-tag"));
  document.querySelectorAll("source[src]").forEach((s) => add(s.src, "tiktok-source"));

  return vids;
}

/* ================================================================
   TWITTER / X
   ============================================================ */
function extractTwitter() {
  const vids = [];
  const seen = new Set();

  function add(url, nama) {
    if (!url || seen.has(url)) return;
    seen.add(url);
    vids.push({ url, nama: nama || "twitter-video", quality: "mp4" });
  }

  // Scan HTML untuk video.twimg.com URLs
  const html = document.documentElement.innerHTML;
  const twitMatches = html.match(/https:\/\/video\.twimg\.com\/[^"'\s<>]+/gi);
  if (twitMatches) {
    twitMatches.slice(0, 30).forEach((url) => {
      const cleanUrl = url.replace(/['";,{}]+$/, "");
      add(cleanUrl, "twitter-video");
    });
  }

  // Scan <video> dan <source> tags
  document.querySelectorAll("video[src]").forEach((v) => add(v.src, "twitter-video-tag"));
  document.querySelectorAll("source[src]").forEach((s) => add(s.src, "twitter-source"));

  // Scan script untuk .mp4 URLs
  const scripts = document.querySelectorAll("script");
  scripts.forEach((script) => {
    if (!script.textContent) return;
    const urls = script.textContent.match(/https:\/\/video\.twimg\.com\/ext_tw_video\/[^"'\s<>]+\.mp4[^"'\s<>]*/gi);
    if (urls) {
      urls.slice(0, 10).forEach((url) => add(url.replace(/['";,]+$/, ""), "twitter-xhr"));
    }
  });

  return vids;
}

/* ================================================================
   Main — jalankan saat halaman siap
   ============================================================ */
(function scanAndSend() {
  if (!PLATFORM) return;

  let vids = [];
  if (PLATFORM === "youtube") vids = extractYouTube();
  else if (PLATFORM === "tiktok") vids = extractTikTok();
  else if (PLATFORM === "twitter") vids = extractTwitter();

  // Retry beberapa kali karena JS player mungkin belum load
  if (vids.length === 0) {
    let tries = 0;
    const interval = setInterval(() => {
      tries++;
      if (PLATFORM === "youtube") vids = extractYouTube();
      else if (PLATFORM === "tiktok") vids = extractTikTok();
      else if (PLATFORM === "twitter") vids = extractTwitter();
      if (vids.length > 0 || tries >= 10) {
        clearInterval(interval);
        if (vids.length > 0) {
          chrome.runtime.sendMessage({
            type: "DM_VIDEOS_DETECTED",
            platform: PLATFORM,
            videos: vids,
            tabUrl: location.href,
          }).catch(() => {}); // tab bisa ditutup sebelum kirim
          // Juga kasih tau DOM
          window.postMessage({
            type: "DM_VIDEOS_READY",
            platform: PLATFORM,
            videos: vids,
          }, "*");
        }
      }
    }, 800);
    // Stop setelah 8 detik total
    setTimeout(() => clearInterval(interval), 8000);
  } else {
    chrome.runtime.sendMessage({
      type: "DM_VIDEOS_DETECTED",
      platform: PLATFORM,
      videos: vids,
      tabUrl: location.href,
    }).catch(() => {});
    window.postMessage({
      type: "DM_VIDEOS_READY",
      platform: PLATFORM,
      videos: vids,
    }, "*");
  }
})();
