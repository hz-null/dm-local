// background.js — service worker (MV3)
//
// Tugas:
//  1. Intersep klik/download biasa -> kirim ke dm_server, batalkan download bawaan Chrome.
//  2. Menu klik kanan "Download dengan DM".
//  3. Menyimpan token di chrome.storage.local.
//
// Catatan penting MV3: service worker bisa mati kapan saja.
// Jangan simpan state di variabel global — selalu baca dari chrome.storage.

const DEFAULT_PORT = 8787;
const DEFAULT_CONNS = 8;

async function cfg() {
  const s = await chrome.storage.local.get({
    port: DEFAULT_PORT,
    conns: DEFAULT_CONNS,
    token: "",
    aktif: true,
  });
  return s;
}

function dasar(port) {
  return `http://127.0.0.1:${port}`;
}

async function kirim(path, body, method = "POST") {
  const c = await cfg();
  if (!c.token) throw new Error("Token belum diisi. Buka popup extension.");
  const r = await fetch(dasar(c.port) + path, {
    method,
    headers: { "Content-Type": "application/json", "X-DM-Token": c.token },
    body: method === "GET" ? undefined : JSON.stringify(body || {}),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || j.ok === false) throw new Error(j.error || `HTTP ${r.status}`);
  return j;
}

async function notif(judul, isi) {
  try {
    await chrome.notifications.create({
      type: "basic",
      iconUrl: "icon128.png",
      title: judul,
      message: isi,
    });
  } catch (_) {
    // ikon belum ada -> abaikan, notifikasi opsional
  }
}

// ---------- 1. intersep download ----------
// PENTING (temuan uji nyata di Chromium + MV3):
//   chrome.downloads.onDeterminingFilename TERDAFTAR tapi TIDAK PERNAH dipanggil
//   pada service worker MV3 — download tetap jalan sendiri di Chrome.
//   Yang benar-benar bereaksi adalah chrome.downloads.onCreated.
//   Strategi: batalkan download Chrome, lalu titipkan URL ke dm_server.
const sudahDitangani = new Set();

chrome.downloads.onCreated.addListener((item) => {
  handle(item).catch(() => {});     // jangan pernah biarkan error menggantung
});

async function handle(item) {
  // jangan sentuh download milik extension lain, dan jangan proses dua kali
  if (item.byExtensionId || sudahDitangani.has(item.id)) return;
  if (!/^https?:/i.test(item.url)) return;

  const c = await cfg();
  if (!c.aktif || !c.token) return;

  sudahDitangani.add(item.id);
  try {
    // item.filename saat onCreated masih berupa GUID acak, bukan nama asli.
    // Jadi nama lebih akurat diambil dari URL; server akan mengoreksi dari
    // Content-Disposition kalau ada.
    let nama = "";
    try {
      const u = new URL(item.url);
      nama = decodeURIComponent(u.pathname.split("/").pop() || "");
      if (!/\.[a-z0-9]{2,5}$/i.test(nama)) {
        const nameParam = u.searchParams.get("name");
        if (nameParam) nama = decodeURIComponent(nameParam);
      }
    } catch (_) { /* biarkan kosong */ }
    if (!nama || !/\.[a-z0-9]{2,5}$/i.test(nama)) nama = "download.bin";

    await kirim("/add", { url: item.url, nama, conns: c.conns });
    await chrome.downloads.cancel(item.id);
    await chrome.downloads.erase({ id: item.id });
    notif("Dialihkan ke DM", nama);
  } catch (e) {
    // server mati / token salah -> biarkan Chrome meneruskan download normal
    notif("DM tidak tersedia, lanjut di Chrome", String(e.message || e).slice(0, 110));
  }
}

// ---------- 2. menu klik kanan ----------
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "dm-download",
    title: "Download dengan DM",
    contexts: ["link", "image", "video", "audio"],
  });
});

chrome.contextMenus.onClicked.addListener(async (info) => {
  const url = info.linkUrl || info.srcUrl;
  if (!url) return;
  const nama = (() => {
    try {
      const u = new URL(url);
      let n = decodeURIComponent(u.pathname.split("/").pop().split("?")[0]);
      if (!/\.[a-z0-9]{2,5}$/i.test(n)) {
        const nameParam = u.searchParams.get("name");
        if (nameParam) n = decodeURIComponent(nameParam);
      }
      return n || "download.bin";
    } catch (_) {
      return "download.bin";
    }
  })();
  try {
    const c = await cfg();
    await kirim("/add", { url, nama, conns: c.conns });
    notif("Dikirim ke DM", nama);
  } catch (e) {
    notif("Gagal kirim", String(e.message || e).slice(0, 120));
  }
});

// ---------- 3. fungsi inti (dipanggil langsung, dan lewat pesan) ----------
// PENTING: chrome.runtime.sendMessage dari dalam service worker TIDAK sampai ke
// listener milik service worker itu sendiri. Jadi logika dipisah ke fungsi,
// lalu popup memanggilnya lewat onMessage. Jangan mengandalkan sendMessage ke diri sendiri.
async function api(tipe, payload) {
  if (tipe === "list") return await kirim("/list", null, "GET");
  if (tipe === "ping") {
    const c = await cfg();
    const r = await fetch(dasar(c.port) + "/ping");
    return await r.json();
  }
  if (tipe === "aksi") return await kirim("/" + payload.aksi, payload.body);
  if (tipe === "buka") {
    const c = await cfg();
    let url;
    if (payload.folder && !payload.id) {
      // Buka folder download itu sendiri (tombol 📁 di header)
      url = new URL(dasar(c.port) + "/download-folder");
    } else {
      url = new URL(dasar(c.port) + "/open");
      url.searchParams.set("id", payload.id);
      if (payload.folder) url.searchParams.set("folder", "1");
    }
    const r = await fetch(url, { headers: { "X-DM-Token": c.token } });
    return await r.json().catch(() => ({ ok: false }));
  }
  if (tipe === "config") {
    await chrome.storage.local.set(payload.data);
    return { ok: true };
  }
  if (tipe === "config-baca") return { ok: true, data: await cfg() };
  throw new Error("pesan tidak dikenal: " + tipe);
}

globalThis.__dmApi = api;

chrome.runtime.onMessage.addListener((msg, _sender, balas) => {
  api(msg.tipe, msg).then(balas, (e) => balas({ ok: false, error: String(e.message || e) }));
  return true; // async
});
