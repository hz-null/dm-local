// popup.js — UI extension. Tidak menyimpan state sendiri; semua ke background.

const $ = (id) => document.getElementById(id);
let timer = null;

function fmtBytes(b) {
  if (!b) return "0 B";
  const u = ["B", "KB", "MB", "GB"];
  let i = 0;
  while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
  return `${b.toFixed(b < 10 && i > 0 ? 1 : 0)} ${u[i]}`;
}

function fmtEta(s) {
  if (s == null) return "—";
  const m = Math.floor(s / 60), d = s % 60;
  return m > 0 ? `${m}m ${d}s` : `${d}s`;
}

async function pesan(msg) {
  return await chrome.runtime.sendMessage(msg);
}

async function cekStatus() {
  const el = $("status");
  try {
    const r = await pesan({ tipe: "ping" });
    if (r && r.ok) {
      el.textContent = "tersambung";
      el.className = "pill on";
      return true;
    }
    throw new Error("balasan kosong");
  } catch (e) {
    el.textContent = "server mati";
    el.className = "pill off";
    return false;
  }
}

function render(tasks) {
  const wadah = $("daftar");
  if (!tasks.length) {
    wadah.innerHTML = '<div class="kosong">belum ada download</div>';
    return;
  }
  // yang aktif di atas, selesai di bawah
  const urut = [...tasks].sort((a, b) => {
    const rank = (t) => (t.state === "done" || t.state === "error" ? 1 : 0);
    return rank(a) - rank(b);
  });
  wadah.innerHTML = urut.map((t) => {
    // Task selesai/gagal: list text ringkas (judul + size), tanpa tombol
    if (t.state === "done" || t.state === "error") {
      const galat = t.error ? ` — <span style="color:var(--err)">${t.error}</span>` : "";
      return `<div class="task done-list">
        <span class="done-check">${t.state === "done" ? "✓" : "✗"}</span>
        <span class="done-name" title="${t.nama}">${t.nama}</span>
        <span class="done-size">${t.state === "done" ? fmtBytes(t.size) : "gagal"}</span>
        <button data-a="open" data-i="${t.id}" title="Buka folder">📁</button>
        <button data-a="remove" data-i="${t.id}" title="Hapus dari list">🗑</button>
      </div>${galat}`;
    }
    // Task aktif: card dengan progress bar + tombol aksi
    const persen = t.persen;
    const ket = `${fmtBytes(t.done)} / ${fmtBytes(t.size)} · ${fmtBytes(t.speed)}/s · ${fmtEta(t.eta)}`;
    const tombol = t.state === "running"
      ? `<button data-a="pause" data-i="${t.id}">Jeda</button>
         <button data-a="cancel" data-i="${t.id}">Batal</button>`
      : `<button data-a="resume" data-i="${t.id}">⚡ Lanjut</button>
         <button data-a="remove" data-i="${t.id}">Hapus</button>`;
    return `<div class="task">
      <div class="tnama"><span>${t.nama}</span><span>${persen}%</span></div>
      <div class="bar"><i class="" style="width:${Math.min(persen, 100)}%"></i></div>
      <div class="meta"><span>${ket}</span><span>${t.state}</span></div>
      <div class="aksi">${tombol}</div>
    </div>`;
  }).join("");
}

async function muat() {
  try {
    const r = await pesan({ tipe: "list" });
    if (r.ok) render(r.tasks);
    else throw new Error(r.error);
    $("galat").textContent = "";
  } catch (e) {
    $("galat").textContent = "Tidak bisa membaca daftar: " + (e.message || e);
  }
}

async function mulai() {
  // muat konfigurasi
  const c = await pesan({ tipe: "config-baca" });
  if (c.ok) {
    $("token").value = c.data.token || "";
    $("port").value = c.data.port;
    $("conns").value = c.data.conns;
    $("aktif").checked = !!c.data.aktif;
  }
  const hidup = await cekStatus();
  if (hidup) await muat();

  // polling ringan; popup mati begitu ditutup, jadi tidak bocor
  timer = setInterval(async () => {
    if (await cekStatus()) await muat();
  }, 1200);
}

$("tambah").addEventListener("click", async () => {
  const url = $("url").value.trim();
  if (!url) return;
  try {
    const r = await pesan({ tipe: "aksi", aksi: "add", body: { url } });
    if (!r.ok) throw new Error(r.error);
    $("url").value = "";
    await muat();
  } catch (e) {
    $("galat").textContent = e.message || String(e);
  }
});

$("url").addEventListener("keydown", (e) => {
  if (e.key === "Enter") $("tambah").click();
});

$("yt-tambah").addEventListener("click", async () => {
  const url = $("yt-url").value.trim();
  if (!url) return;
  const quality = $("yt-quality")?.value || "best";
  try {
    const r = await pesan({ tipe: "aksi", aksi: "yt-download", body: { url, quality } });
    if (!r.ok) throw new Error(r.error);
    $("yt-url").value = "";
    await muat();
  } catch (e) {
    $("galat").textContent = e.message || String(e);
  }
});

$("yt-url").addEventListener("keydown", (e) => {
  if (e.key === "Enter") $("yt-tambah").click();
});

$("buka-folder").addEventListener("click", async () => {
  try {
    const r = await pesan({ tipe: "buka", folder: true });
    if (!r.ok) throw new Error(r.error);
  } catch (err) {
    $("galat").textContent = err.message || String(err);
  }
});

$("daftar").addEventListener("click", async (e) => {
  const b = e.target.closest("button[data-a]");
  if (!b) return;
  const aksi = b.dataset.a;
  try {
    if (aksi === "open") {
      const r = await pesan({
        tipe: "buka", id: b.dataset.i, folder: true,
      });
      if (!r.ok) throw new Error(r.error);
      return;
    }
    const r = await pesan({
      tipe: "aksi", aksi,
      body: { id: b.dataset.i, hapus_file: false },
    });
    if (!r.ok) throw new Error(r.error);
    await muat();
  } catch (err) {
    $("galat").textContent = err.message || String(err);
  }
});

$("simpan").addEventListener("click", async () => {
  await pesan({
    tipe: "config",
    data: {
      token: $("token").value.trim(),
      port: parseInt($("port").value, 10) || 8787,
      conns: Math.min(Math.max(parseInt($("conns").value, 10) || 8, 1), 16),
      aktif: $("aktif").checked,
    },
  });
  $("galat").textContent = "";
  if (await cekStatus()) await muat();
});

window.addEventListener("unload", () => clearInterval(timer));
mulai();
