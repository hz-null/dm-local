"""
dm_server.py — jembatan localhost antara browser extension dan engine.

Kenapa butuh server?
  Extension tidak bisa menulis file ke disk sesukanya (sandbox browser).
  Extension "menitip" URL ke program lokal lewat HTTP di 127.0.0.1.

Keamanan (penting, jangan dilewat):
  1. Bind hanya ke 127.0.0.1 — tidak bisa diakses dari jaringan.
  2. Token acak wajib di header X-DM-Token. Tanpa token, request ditolak.
      Tanpa token, situs web mana pun bisa menitipkan download ke komputermu.
  3. Origin harus chrome-extension:// atau kosong (curl). Origin http/https ditolak,
      jadi halaman web tidak bisa memanggil server ini walau tahu port & token.

Jalankan:
    python dm_server.py                # folder default: ./downloads
    python dm_server.py -d D:/unduhan -p 8787
"""
from __future__ import annotations

import argparse
import json
import os
import secrets
import subprocess
import sys
import threading
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

from dm_engine import Engine

TOKEN = secrets.token_urlsafe(24)
ENGINE: Engine | None = None
STATE = {"conns": 8}


def _origin_ok(h):
    o = h.headers.get("Origin")
    if o is None:
        return True                      # curl / alat lokal
    return o.startswith("chrome-extension://") or o.startswith("moz-extension://")


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    # ---------- util ----------
    def _json(self, obj, kode=200):
        b = json.dumps(obj).encode()
        self.send_response(kode)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Access-Control-Allow-Origin", self.headers.get("Origin") or "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-DM-Token")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()
        self.wfile.write(b)

    def _err(self, pesan, kode=400):
        self._json({"ok": False, "error": pesan}, kode)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        try:
            return json.loads(self.rfile.read(n) or b"{}")
        except json.JSONDecodeError:
            return {}

    def log_message(self, fmt, *args):
        pass                              # jangan spam konsol

    # ---------- routing ----------
    def do_OPTIONS(self):
        if not _origin_ok(self):
            return self._err("origin ditolak", 403)
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", self.headers.get("Origin") or "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-DM-Token")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()

    def do_GET(self):
        if not _origin_ok(self):
            return self._err("origin ditolak: server ini hanya untuk extension", 403)
        p = urlparse(self.path).path
        if p == "/ping":
            return self._json({"ok": True, "app": "dm_server", "version": 1})
        if p == "/list":
            if not self._auth():
                return
            return self._json({"ok": True, "tasks": ENGINE.semua()})
        if p == "/open":
            if not self._auth():
                return
            qs = parse_qs(urlparse(self.path).query)
            tid = qs.get("id", [None])[0]
            buka_folder = qs.get("folder", ["0"])[0] == "1"
            t = ENGINE.get(tid) if tid else None
            if not t:
                return self._err("task tidak ditemukan", 404)
            path = os.path.dirname(t.target) if buka_folder else t.target
            if not os.path.exists(path):
                return self._err(f"file belum ada di disk: {t.nama}", 404)
            try:
                # explorer.exe dengan path — lebih reliable dari os.startfile
                # untuk memastikan window muncul di foreground
                subprocess.Popen(["explorer", path])
                return self._json({"ok": True, "path": path})
            except OSError as e:
                return self._err(f"gagal membuka: {e}", 500)
        if p == "/download-folder":
            if not self._auth():
                return
            folder = os.path.abspath(ENGINE.folder)
            try:
                subprocess.Popen(["explorer", folder])
                return self._json({"ok": True, "path": folder})
            except OSError as e:
                return self._err(f"gagal membuka: {e}", 500)
        self._err("tidak ditemukan", 404)

    def do_POST(self):
        if not _origin_ok(self):
            return self._err("origin ditolak: server ini hanya untuk extension", 403)
        if not self._auth():
            return
        p = urlparse(self.path).path
        b = self._body()

        if p == "/add":
            url = (b.get("url") or "").strip()
            if not url.startswith(("http://", "https://")):
                return self._err("url harus http/https")
            t = ENGINE.add(url, nama=b.get("nama"), conns=int(b.get("conns") or STATE["conns"]))
            return self._json({"ok": True, "id": t.id, "nama": t.nama})

        if p == "/yt-download":
            url = (b.get("url") or "").strip()
            if not url:
                return self._err("url tidak boleh kosong")
            ytdlp = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tools", "yt-dlp.exe")
            if not os.path.exists(ytdlp):
                return self._err("yt-dlp.exe tidak ditemukan di tools/")
            t = ENGINE.add_yt(url, ytdlp, quality=b.get("quality") or "best")
            return self._json({"ok": True, "id": t.id})

        if p in ("/pause", "/resume", "/cancel", "/remove"):
            t = ENGINE.get(b.get("id") or "")
            if not t:
                return self._err("id tidak dikenal", 404)
            if p == "/pause":
                t.pause()
            elif p == "/resume":
                # Terima "paused" (Jeda) DAN "queued" (setelah Batal). Tanpa
                # cek ini, klik Lanjut berulang men-spawn banyak thread untuk
                # task yang sama dan progresnya jadi ngawur.
                if t.state in ("paused", "queued"):
                    t.lanjut()
                    threading.Thread(target=t.run, daemon=True).start()
            elif p == "/cancel":
                t.byte_offset = t.hitung()   # simpan progres biar resume lancar
                t.stop()
                t.state = "paused"
            elif p == "/remove":
                ENGINE.hapus(t.id, hapus_file=bool(b.get("hapus_file")))
            return self._json({"ok": True, "task": t.info() if p != "/remove" else None})

        if p == "/settings":
            if "conns" in b:
                STATE["conns"] = max(1, min(int(b["conns"]), 16))
            return self._json({"ok": True, **STATE})

        self._err("tidak ditemukan", 404)

    def _auth(self):
        if self.headers.get("X-DM-Token") != TOKEN:
            self._err("token salah. ambil dari file token.txt", 401)
            return False
        return True


def main():
    # PENTING: TOKEN harus global. Tanpa ini, assignment di dalam main() membuat
    # variabel LOKAL, dan Handler tetap memakai token acak hasil import ->
    # semua request ditolak "token salah" walau token.txt sudah benar.
    global ENGINE, TOKEN
    ap = argparse.ArgumentParser(description="Server lokal untuk extension download manager")
    ap.add_argument("-d", "--dir", default=os.path.join(os.getcwd(), "downloads"))
    ap.add_argument("-p", "--port", type=int, default=8787)
    ap.add_argument("-c", "--conns", type=int, default=8)
    a = ap.parse_args()

    # Di Windows, SO_REUSEADDR membuat DUA proses bisa bind ke port yang sama.
    # Akibatnya request bisa nyasar ke server lama (token beda) dan muncul
    # "token salah" yang membingungkan. Matikan.
    ThreadingHTTPServer.allow_reuse_address = False

    # Tolak jalan kalau sudah ada server lain di port ini -> pesan jelas, bukan diam.
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{a.port}/ping", timeout=2) as r:
            info = json.loads(r.read())
            if info.get("app") == "dm_server":
                print(f"!! Port {a.port} sudah dipakai DM Server lain yang masih hidup.")
                print("   Tutup jendela server yang lama, lalu jalankan lagi.")
                print(f"   Token server lama ada di {os.path.join(os.path.dirname(os.path.abspath(__file__)), 'token.txt')}")
                input("\nTekan Enter untuk keluar...")
                return
    except Exception:  # noqa: BLE001
        pass    # tidak ada yang mendengarkan -> aman lanjut

    ENGINE = Engine(os.path.abspath(a.dir))
    STATE["conns"] = max(1, min(a.conns, 16))

    token_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "token.txt")
    # Token tetap disimpan supaya tidak perlu disalin ulang tiap server dinyalakan.
    # Hanya dibuat sekali; hapus file token.txt kalau ingin token baru.
    if os.path.exists(token_path) and os.path.getsize(token_path) > 20:
        with open(token_path) as f:
            TOKEN = f.read().strip()
    else:
        with open(token_path, "w") as f:
            f.write(TOKEN)

    srv = ThreadingHTTPServer(("127.0.0.1", a.port), Handler)
    print("=" * 62)
    print("  DM Server siap")
    print(f"  alamat     : http://127.0.0.1:{a.port}")
    print(f"  folder     : {ENGINE.folder}")
    print(f"  koneksi    : {STATE['conns']}")
    print(f"  token      : {TOKEN}")
    print(f"  token file : {token_path}")
    print("=" * 62)
    print("  Salin token di atas ke popup extension (sekali saja).")
    print("  Ctrl+C untuk berhenti.\n")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nberhenti.")
        srv.shutdown()


if __name__ == "__main__":
    main()
