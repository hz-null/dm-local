# Download Manager dari Nol

Download manager segmented + resume, dengan extension Chrome, ditulis dan **diuji nyata**
di Windows. Bukan contoh dari internet.

## Mulai cepat

| File | Fungsi |
|---|---|
| **`1_jalankan_server.bat`** | Nyalakan server untuk extension. **Jangan tutup jendelanya.** |
| **`2_unduh_lewat_terminal.bat`** | Unduh file tanpa extension. Bisa tarik-lepas URL ke file ini. |
| `3_uji_resume.bat` | Uji fitur resume ke server internet. |
| **`4_audit_sendiri.bat`** | Uji seluruh sistem (15 pemeriksaan). Hasil harus "SEMUA LULUS". |
| **`5_tutup_semua_server.bat`** | Tutup semua jendela server yang menumpuk sekaligus. |

**Berapa jendela server yang seharusnya terbuka?** Satu saja. Kalau ada lebih dari
satu, jalankan `5_tutup_semua_server.bat` lalu nyalakan satu kali lagi.

Tidak butuh Python terpasang — `.bat` memakai Python bawaan Hermes.

### Pasang extension (sekali saja)

1. Jalankan `1_jalankan_server.bat`, catat **token** yang muncul.
2. Buka `chrome://extensions`
3. Aktifkan **Mode pengembang**
4. **Muat yang belum dipaketkan** → pilih folder `extension`
5. Klik ikon puzzle → **DM Local** → **Pengaturan**
6. Tempel token, port `8787`, koneksi `4` → **Simpan**

Token disimpan di `token.txt` dan tidak berubah antar restart.

## Hasil audit terakhir

```
--- 1. KEAMANAN ---
  [LULUS] token salah ditolak            HTTP 401
  [LULUS] origin halaman web ditolak     HTTP 403
  [LULUS] URL non-http ditolak           HTTP 400
--- 2. INTEGRITAS ---
  [LULUS] download selesai
  [LULUS] SHA-256 identik
--- 3. RETRY (server rewel 30%) ---
  [LULUS] selesai walau 30% request gagal
  [LULUS] hasil tetap utuh
--- 4. JEDA / LANJUT ---
  [LULUS] progres tidak turun setelah jeda/lanjut
  [LULUS] selesai setelah jeda berulang
--- 5. RESUME setelah server mati ---
  [LULUS] progres lama dikenali            mati di 50%, dikenali 52%
  [LULUS] resume lebih cepat dari nol      resume 3.3s vs nol 6.5s
  [LULUS] hasil resume utuh
--- 6. PENANGANAN ERROR ---
  [LULUS] 404 menjadi error, bukan done
  [LULUS] tidak meninggalkan file rusak
  [LULUS] host mati dilaporkan gagal
HASIL: SEMUA LULUS
```

## Arsitektur

```
Chrome  ──klik download──▶  extension (service worker)
                                  │ POST /add + X-DM-Token
                                  ▼
                          dm_server.py  (127.0.0.1:8787)
                                  │
                                  ▼
                          dm_engine.py  (segmented + resume)
                                  │
                                  ▼
                          downloads/*.bin
```

| File | Isi |
|---|---|
| `dm_engine.py` | Engine inti: segmen, resume, retry, verifikasi ukuran |
| `dm_server.py` | HTTP server lokal + autentikasi token |
| `dm.py` | Versi CLI (tanpa server) |
| `extension/` | Manifest V3: background.js, popup |
| `audit.py` | 15 pemeriksaan otomatis |
| `uji_server_lokal.py` | Server uji: Range, throttle, mode rewel (429/putus) |
| `tahap1..3*.py` | Materi belajar bertahap |

## Tiga konsep inti

**1. Header `Range`**
```
GET /file.bin
Range: bytes=1310720-2621439
```
Server balas `206 Partial Content`. Kalau balas `200`, Range diabaikan → file tidak bisa dipecah.

**2. Progres = ukuran file `.part`**
Tidak perlu database. `file.part3` berukuran 5 MB artinya segmen 3 sudah dapat 5 MB.
Lanjut dengan `Range: bytes=(start+5MB)-(end)`, buka file mode `"ab"`.

**3. Gabung + verifikasi**
Salin `part0`, `part1`, ... berurutan. **Lalu bandingkan ukuran akhir dengan
`Content-Length`.** Tanpa langkah ini, download terpotong akan dilaporkan "selesai"
padahal rusak.

## Hasil pengukuran nyata

Kecepatan vs jumlah koneksi (jaringan rumah, OVH 100 MB):

| Koneksi | MB/s |
|---|---|
| 1 | 1.88 |
| 2 | 1.61 |
| 4 | 1.73 |
| 8 | 2.01 |
| 16 | 1.72 |

**Kesimpulan:** jumlah koneksi hampir tidak berpengaruh. Yang menentukan adalah
bandwidth kamu dan kecepatan server. Multi-koneksi hanya menangkal throttle
*per-koneksi*. Klaim "IDM 8x lebih cepat" menyesatkan — yang diukur biasanya
kasus khusus.

## Keamanan

Server ini **hanya menerima** dari extension sendiri:

- Bind ke `127.0.0.1` — tidak bisa diakses dari jaringan/HP lain.
- Token wajib di header `X-DM-Token` (32 karakter acak, tersimpan di `token.txt`).
- `Origin` selain `chrome-extension://` ditolak (`403`) — halaman web tidak bisa
  menitipkan download walau tahu port dan token.
- Hanya URL `http`/`https` — `file://` ditolak.

Kalau token bocor, hapus `token.txt` lalu jalankan server lagi untuk token baru.

## Bug nyata yang ditemukan saat pengembangan

Ini yang membuat proyek begini gagal di tangan orang lain:

1. **`chrome.downloads.onDeterminingFilename` tidak pernah dipanggil di MV3.**
   Terdaftar tanpa error, tapi tidak bereaksi. Harus pakai `onCreated` + `cancel()`.
2. **Dua server bisa bind ke port yang sama di Windows** (`SO_REUSEADDR`) →
   request nyasar ke server lama, muncul "token salah" yang membingungkan.
3. **`global TOKEN` lupa ditulis** → server memakai token acak, semua request 401.
4. **Exception di dalam thread mati diam-diam** → program bilang "belum lengkap"
   tanpa alasan.
5. **Resume men-spawn worker kedua** saat thread lama masih menunggu `pause`
   → dua penulis per segmen, progres ngawur, file rusak.
6. **Klik "Lanjut" pada task yang sudah selesai** → file `.part` sudah dihapus,
   jadi mengunduh ulang dari nol dan persen terlihat turun 100% → 7%.
7. **`hitung()` hanya menjumlahkan `part0`** saat segmen belum diketahui →
   setelah restart progres tampak 0% padahal 50 MB ada di disk.
8. **Tanpa verifikasi ukuran akhir** → download terpotong dilaporkan "done".
9. **`.bat` dengan loop `goto ulang` menyalakan server kembali setiap kali prosesnya
   dimatikan** → jendela cmd menumpuk tanpa batas. Satu kali jalan, tanpa loop.

## Batasan (jujur)

Yang **belum** didukung:

- **Video streaming** (YouTube/IG/TikTok) — butuh `yt-dlp`, bukan downloader biasa.
- **Situs yang butuh login/cookie** — server tidak membawa sesi browser.
- **Antrian & jadwal** — belum ada scheduler atau batas kecepatan.
- **Distribusi ke orang lain** — `.exe` tanpa code signing akan kena SmartScreen.

Untuk pemakaian pribadi, ini sudah cukup. Untuk dipakai banyak orang, extension
harus dipublish ke Chrome Web Store dan app perlu code signing (~$100–400/tahun).

## Uji sendiri

```bash
python audit.py          # atau klik 4_audit_sendiri.bat
```

File uji internet (kalau perlu): `https://proof.ovh.net/files/10Mb.dat` —
tapi OVH membatasi kalau dipakai berulang cepat. `uji_server_lokal.py` lebih
stabil karena berjalan di komputer sendiri.
