@echo off
title Unduh File
cd /d "%~dp0"
color 0A
echo.
echo   ================================================
echo     Unduh File
echo   ================================================
echo.
if "%~1"=="" (
  set /p URL="Tempel URL file lalu Enter: "
) else (
  set "URL=%~1"
)
echo.
echo   Mengunduh: %URL%
echo.
"%~dp0python\python.exe" dm.py "%URL%"

echo.
echo   -------------------------------------------------
pause
