@echo off
title DM Server - biarkan terbuka
cd /d "%~dp0"
color 0A
echo.
echo   ================================================
echo     DM Server - biarkan terbuka
echo   ================================================
echo.
"%~dp0python\python.exe" dm_server.py -d "%~dp0downloads" -p 8787

echo.
echo   -------------------------------------------------
pause
