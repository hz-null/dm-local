"""
uji_keamanan.py — membuktikan program hanya menyentuh folder-nya sendiri.

Membuat file "umpan" di luar folder download (menyerupai data pribadi), lalu
memastikan seluruh operasi download/hapus/ganti-nama TIDAK menyentuhnya.

Jalankan dari folder DM-Local:
    python uji_keamanan.py
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
PY = os.path.join(HERE, "python", "python.exe")
if not os.path.exists(PY):
    PY = sys.executable

PORT = 8808
UJI_PORT = 8895
DL = os.path.join(HERE, "downloads_sandbox")
LUAR = os.path.join(HERE, "DATA_PENTING_UMPAN")
FAIL = []


def cek(nama, lulus, info=""):
    print(f"  [{'LULUS' if lulus else 'GAGAL'}] {nama}" + (f"  — {info}" if info else ""))
    if not lulus:
        FAIL.append(nama)


def tunggu(url, batas=40):
    t0 = time.time()
    while time.time() - t0 < batas:
        try:
            urllib.request.urlopen(url, timeout=1).read()
            return True
        except Exception:  # noqa: BLE001
            time.sleep(0.15)
    return False


def main():
    for d in (DL, LUAR):
        shutil.rmtree(d, ignore_errors=True)
    os.makedirs(DL, exist_ok=True)
    os.makedirs(LUAR, exist_ok=True)

    # ==== UMPAN: file di luar folder download, menyerupai data pribadi ====
    umpan = {
        "foto_keluarga.jpg": b"data pribadi yang tidak boleh disentuh",
        "dokumen_penting.docx": b"rahasia",
        "KTP_scan.pdf": b"identitas",
    }
    for nama, isi in umpan.items():
        with open(os.path.join(LUAR, nama), "wb") as f:
            f.write(isi)
    sha_awal = {n: hashlib.sha256(open(os.path.join(LUAR, n), "rb").read()).hexdigest()
                for n in umpan}
    print(f"umpan dibuat di {LUAR} ({len(umpan)} file)")

    # catat juga isi folder induk sebelum
    sebelum_induk = set(os.listdir(HERE))

    uji = subprocess.Popen([PY, os.path.join(HERE, "uji_server_lokal.py"),
                            "-p", str(UJI_PORT), "-s", "4", "-t", "6"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    srv = subprocess.Popen([PY, os.path.join(HERE, "dm_server.py"),
                            "-d", DL, "-p", str(PORT)],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if not tunggu(f"http://127.0.0.1:{PORT}/ping") or not tunggu(f"http://127.0.0.1:{UJI_PORT}/uji.bin"):
        print("server gagal hidup")
        return 1

    tok = open(os.path.join(HERE, "token.txt")).read().strip()

    def api(path, body=None, m="POST"):
        req = urllib.request.Request(
            f"http://127.0.0.1:{PORT}" + path,
            data=None if m == "GET" else json.dumps(body or {}).encode(),
            headers={"Content-Type": "application/json", "X-DM-Token": tok},
            method=m)
        with urllib.request.urlopen(req, timeout=40) as r:
            return json.loads(r.read())

    def task(n):
        for t in api("/list", m="GET")["tasks"]:
            if t["nama"] == n:
                return t
        return None

    def tunggu_selesai(n, batas=120):
        t0 = time.time()
        while time.time() - t0 < batas:
            t = task(n)
            if t and t["state"] in ("done", "error"):
                return t
            time.sleep(0.3)
        return task(n)

    print("\n--- A. download normal tidak menyentuh data luar ---")
    api("/add", {"url": f"http://127.0.0.1:{UJI_PORT}/uji.bin", "nama": "aman.bin", "conns": 4})
    t = tunggu_selesai("aman.bin")
    cek("download selesai", t and t["state"] == "done", (t or {}).get("state", "?"))

    print("\n--- B. coba path traversal lewat nama file ---")
    # Upaya jahat: nama file berisi ../ supaya menulis ke luar folder download
    api("/add", {"url": f"http://127.0.0.1:{UJI_PORT}/uji.bin",
                 "nama": "../../../DATA_PENTING_UMPAN/bocor.bin", "conns": 2})
    time.sleep(6)
    bocor = os.path.exists(os.path.join(LUAR, "bocor.bin"))
    cek("nama file berisi ../ tidak menulis ke luar", not bocor,
        "DITOLAK" if not bocor else "BOCOR!")
    beda = [f for f in os.listdir(LUAR) if f not in umpan]
    cek("tidak ada file baru di folder luar", not beda, ", ".join(beda) if beda else "")

    print("\n--- C. hapus task tidak menghapus file di luar ---")
    # Tunggu sampai task benar-benar selesai, baru hapus. Task yang dihapus
    # saat masih berjalan akan terus menulis, dan itu bukan kebocoran data.
    tunggu_selesai("aman.bin")
    tid = task("aman.bin")
    if tid:
        api("/remove", {"id": tid["id"], "hapus_file": True})
        time.sleep(1.5)
    cek("file milik task dibersihkan dari folder download",
        not any(f.startswith("aman.bin") for f in os.listdir(DL)),
        ", ".join(sorted(os.listdir(DL))) or "kosong")
    for nama in umpan:
        cek(f"umpan '{nama}' masih ada", os.path.exists(os.path.join(LUAR, nama)))

    print("\n--- D. isi umpan tidak berubah ---")
    for nama, sha in sha_awal.items():
        p = os.path.join(LUAR, nama)
        if os.path.exists(p):
            sekarang = hashlib.sha256(open(p, "rb").read()).hexdigest()
            cek(f"SHA '{nama}' identik", sekarang == sha)

    print("\n--- E. server tidak mendengarkan di jaringan luar ---")
    hasil_luar = []
    try:
        import socket
        ip = socket.gethostbyname(socket.gethostname())
        o = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             f"Get-NetTCPConnection -State Listen -LocalPort {PORT} | "
             f"Select-Object -ExpandProperty LocalAddress"],
            capture_output=True, text=True, timeout=30)
        alamat = [x.strip() for x in o.stdout.splitlines() if x.strip()]
        cek("hanya bind ke 127.0.0.1", alamat and all(x in ("127.0.0.1", "::1") for x in alamat),
            f"alamat: {', '.join(alamat) if alamat else '-'} (IP LAN: {ip})")
        hasil_luar = alamat
    except Exception as e:  # noqa: BLE001
        cek("hanya bind ke 127.0.0.1", False, str(e))

    print("\n--- F. folder induk tidak berubah (tidak ada file nyasar) ---")
    sesudah_induk = set(os.listdir(HERE))
    # Diabaikan: cache Python, token (memang dibuat server), dan folder uji.
    wajar = {"__pycache__", "token.txt", "downloads_sandbox", "DATA_PENTING_UMPAN"}
    baru = sesudah_induk - sebelum_induk - wajar
    cek("tidak ada file tak terduga di folder program", not baru,
        ", ".join(sorted(baru)) if baru else "")

    for p in (srv, uji):
        try:
            p.kill()
        except Exception:  # noqa: BLE001
            pass

    shutil.rmtree(LUAR, ignore_errors=True)
    shutil.rmtree(DL, ignore_errors=True)

    print("\n" + "=" * 52)
    if FAIL:
        print(f"HASIL: {len(FAIL)} GAGAL -> {', '.join(FAIL)}")
        return 1
    print("HASIL: SEMUA LULUS — program tidak menyentuh data di luar foldernya")
    return 0


if __name__ == "__main__":
    sys.exit(main())
