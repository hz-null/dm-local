"""
dm_engine.py — Engine download yang dipakai bersama oleh CLI (dm.py) dan server (dm_server.py).

Perbedaan penting dibanding dm.py:
  - Berbasis class, bukan global. Bisa banyak download sekaligus tanpa saling ganggu.
  - Tiap task punya threading.Event sendiri untuk pause/stop.
  - Progres dihitung dari ukuran file .part di disk (sumber kebenaran tunggal).

Yang TIDAK berubah: tetap header Range, tetap .part, tetap resume.
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
import urllib.error
import urllib.request
import uuid
import subprocess

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) dm/1.0"}
CHUNK = 256 * 1024
RETRY_MAKS = 6


def _nama_aman(s: str) -> str:
    """Bersihkan nama file dari server/user supaya tidak bisa keluar folder.

    Karakter pemisah path dan titik-titik '..' dibuang total — bukan sekadar
    diganti garis bawah. Tanpa ini nama seperti '../../../KTP.pdf' bisa
    menulis di luar folder download.
    """
    s = s.replace("\\", "/")
    s = s.split("/")[-1]                       # buang semua komponen path
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", s)
    s = s.strip(" .")
    if s in ("", ".", ".."):
        return "download.bin"
    # nama Windows terlarang
    if s.upper().split(".")[0] in {
        "CON", "PRN", "AUX", "NUL",
        *(f"COM{i}" for i in range(1, 10)),
        *(f"LPT{i}" for i in range(1, 10)),
    }:
        s = "_" + s
    return s[:150] or "download.bin"


def probe(url: str):
    """Kembalikan (size, final_url, nama_saran, dukung_range).

    WAJIB punya retry: satu timeout/429 sesaat pada HEAD tidak boleh
    menggagalkan seluruh download. Ini kejadian nyata di jaringan rumah.
    """
    terakhir = None
    for percobaan in range(1, 5):
        try:
            return _probe_sekali(url)
        except urllib.error.HTTPError as e:
            # 4xx (selain 429) = permintaan salah, retry tidak akan menolong.
            if e.code == 404:
                raise RuntimeError("file tidak ditemukan di server (404)") from e
            if e.code in (401, 403):
                raise RuntimeError(
                    "server menolak akses — file butuh login/cookie, "
                    "atau link kedaluwarsa") from e
            if e.code == 429:
                terakhir = e
                if percobaan == 4:
                    break
                time.sleep(6)
                continue
            raise RuntimeError(f"server membalas HTTP {e.code}") from e
        except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:
            terakhir = e
            if percobaan == 4:
                break
            time.sleep(min(2 ** percobaan, 12))
    raise RuntimeError(f"server tidak merespons setelah 4 percobaan: {terakhir}")


def _normalisasi_url(url: str):
    m = re.match(r'https?://pixeldrain\.com/u/([A-Za-z0-9_-]+)(?:[/?]|$)', url)
    if m:
        return f'https://pixeldrain.com/api/file/{m.group(1)}'
    return url

def _probe_sekali(url: str):
    url = _normalisasi_url(url)
    req = urllib.request.Request(url, method="HEAD", headers=UA)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            headers, final = r.headers, r.geturl()
    except urllib.error.HTTPError as e:
        # sebagian server menolak HEAD tapi mau GET
        if e.code not in (403, 405, 501):
            raise
        req = urllib.request.Request(url, headers={**UA, "Range": "bytes=0-0"})
        with urllib.request.urlopen(req, timeout=30) as r:
            headers, final = r.headers, r.geturl()

    size = headers.get("Content-Length")
    ranges = (headers.get("Accept-Ranges") or "none").lower() == "bytes"

    nama = None
    cd = headers.get("Content-Disposition") or ""
    if cd:
        m = re.search(r'filename\*=[^\';\s]*\'[^\';\s]*\'([^;]*)', cd, re.I)
        if m:
            nama = urllib.parse.unquote(m.group(1).strip())
        else:
            m = re.search(r'filename=("(?:[^"\\]|\\.)*"|\'(?:[^\'\\]|\\.)*\'|[^;]+)', cd, re.I)
            if m:
                nama = urllib.parse.unquote(m.group(1).strip())
                if nama and nama[0] in ('"', "'") and nama[-1] == nama[0]:
                    nama = nama[1:-1]
    if not nama:
        from urllib.parse import urlparse, parse_qs, unquote
        parsed = urlparse(final)
        qs = parse_qs(parsed.query)
        if "name" in qs:
            nama = unquote(qs["name"][0])
    if not nama:
        from urllib.parse import urlparse, unquote
        nama = unquote(os.path.basename(urlparse(final).path)) or "download.bin"

    return (int(size) if size and size.isdigit() else None), final, _nama_aman(nama), ranges


def _unik(path_dir, nama, url):
    """Kalau sudah ada task/meta dengan nama sama untuk URL berbeda, beri akhiran."""
    dasar, ext = os.path.splitext(nama)
    kandidat = nama
    i = 2
    while os.path.exists(os.path.join(path_dir, kandidat + ".dm.json")):
        meta_p = os.path.join(path_dir, kandidat + ".dm.json")
        try:
            lama = json.load(open(meta_p))
        except Exception:  # noqa: BLE001
            lama = {}
        if lama.get("url") == url:
            return kandidat            # sesi yang sama -> boleh lanjut
        kandidat = f"{dasar} ({i}){ext}"
        i += 1
    return kandidat


class Segment:
    __slots__ = ("idx", "start", "end")

    def __init__(self, idx, start, end):
        self.idx, self.start, self.end = idx, start, end

    @property
    def perlu(self):
        return self.end - self.start + 1


class Task:
    def __init__(self, url, folder, nama=None, conns=8, task_id=None):
        self.id = task_id or uuid.uuid4().hex[:12]
        self.url = url
        self.folder = folder
        self.conns = max(1, min(conns, 32))
        # Nama dari pemanggil API WAJIB dibersihkan di sini. Tanpa _nama_aman,
        # POST /add dengan nama "../../KTP.pdf" menulis di luar folder download.
        self.nama = _nama_aman(nama) if nama else "pending.bin"
        self.size = None
        self.ranges = False
        self.segmen: list[Segment] = []
        self.state = "queued"        # queued|probing|running|paused|done|error
        self.error = None
        self.created = time.time()
        self.started = None
        self.finished = None
        self._pause = threading.Event()
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self._jalan_lock = threading.Lock()   # hanya satu loop run() aktif
        self._sampel: list[tuple[float, int]] = []   # (waktu, byte) untuk ukur kecepatan
        self._threads: list[threading.Thread] = []
        self._bytes = 0
        self.byte_offset = 0    # byte di mana task terakhir berhenti (untuk resume)

    # ---------- path ----------
    @property
    def target(self):
        return os.path.join(self.folder, self.nama)

    @property
    def meta_path(self):
        return self.target + ".dm.json"

    def part(self, i):
        return f"{self.target}.part{i}"

    # ---------- progres ----------
    def hitung(self):
        # setelah selesai, .part sudah dihapus & digabung -> ukuran akhir adalah kebenaran
        if self.state == "done":
            return self.size or 0
        # yt-dlp: progress di-parse langsung ke _bytes (tidak ada .part file)
        if self._bytes > 0 and not self.segmen:
            return self._bytes
        if not self.segmen:
            # Segmen belum diketahui (masih probing / resume dari sesi lama):
            # jumlahkan SEMUA file .part*, bukan hanya part0. Tanpa ini progres
            # tampak 0% padahal sudah ada puluhan MB di disk.
            total = 0
            for f in os.listdir(self.folder) if os.path.isdir(self.folder) else []:
                if f.startswith(os.path.basename(self.target) + ".part"):
                    try:
                        total += os.path.getsize(os.path.join(self.folder, f))
                    except OSError:
                        pass
            return total
        return sum(os.path.getsize(self.part(s.idx))
                   for s in self.segmen if os.path.exists(self.part(s.idx)))

    def laju_ukur(self):
        """Kecepatan nyata: selisih byte dalam jendela waktu terakhir, bukan rata-rata
        dari awal. Rata-rata dari awal salah setelah resume (byte lama ikut terhitung)."""
        now = time.time()
        b = self.hitung()
        self._sampel.append((now, b))
        # buang sampel lebih tua dari 4 detik
        while len(self._sampel) > 2 and now - self._sampel[0][0] > 4:
            self._sampel.pop(0)
        if len(self._sampel) < 2:
            return 0.0
        t0, b0 = self._sampel[0]
        dt = now - t0
        if dt < 0.25 or b <= b0:
            return 0.0
        return (b - b0) / dt

    def info(self):
        sudah = self.hitung()
        total = self.size or 0
        laju = self.laju_ukur()
        return {
            "id": self.id, "url": self.url, "nama": self.nama, "size": total,
            "done": sudah,
            "persen": round(sudah / total * 100, 1) if total else 0,
            "speed": round(laju),
            "state": self.state, "error": self.error,
            "eta": int((total - sudah) / laju) if laju > 0 and total > sudah else None,
            "folder": self.folder,
        }

    # ---------- kontrol ----------
    def pause(self):
        # task yang sudah selesai/gagal tidak bisa dijeda; kalau dipaksa,
        # state jadi "paused" padahal file sudah utuh -> membingungkan.
        if self.state in ("done", "error"):
            return False
        self._pause.set()
        self.state = "paused"
        self.byte_offset = self.hitung()  # simpan progres saat jeda
        return True

    def lanjut(self):
        # PENTING: jangan lanjutkan task yang sudah selesai. File .part sudah
        # dihapus saat penggabungan, jadi run() akan mengunduh ulang dari nol
        # dan progres terlihat "turun" (100% -> 7%). Ini bug nyata yang pernah
        # terjadi: klik Lanjut pada baris yang sudah selesai.
        if self.state in ("done", "error"):
            return False
        # _stop HARUS dibersihkan: kalau tidak, worker yang baru di-spawn
        # langsung keluar dan task macet selamanya (terjadi setelah Batal).
        self._stop.clear()
        self._pause.clear()
        if self.state in ("paused", "queued"):
            self.state = "running"
        return True

    def stop(self):
        self._stop.set()
        self._pause.clear()

    # ---------- kerja ----------
    def _siapkan(self):
        """Siapkan segmen. Aman dipanggil berulang (idempoten) — run() bisa
        dipanggil lagi saat resume, dan kita tidak mau segmen dihitung ulang."""
        if self.size is not None and self.segmen:
            return
        self.state = "probing"
        size, final, nama_saran, ranges = probe(self.url)
        self.size = size
        self.ranges = ranges
        os.makedirs(self.folder, exist_ok=True)
        if self.nama in ("pending.bin", "download.bin"):
            self.nama = nama_saran
        # jangan biarkan dua task menulis ke file .part yang sama
        self.nama = _unik(self.folder, self.nama, self.url)

        # sudah ada dari sesi sebelumnya?
        if os.path.exists(self.meta_path):
            meta = json.load(open(self.meta_path))
            if meta.get("url") == self.url and meta.get("size") == size:
                self.segmen = [Segment(s["idx"], s["start"], s["end"]) for s in meta["segmen"]]
                self.state = "queued"
                return

        if ranges and size:
            potong = size // self.conns
            self.segmen = [
                Segment(i, i * potong,
                        size - 1 if i == self.conns - 1 else i * potong + potong - 1)
                for i in range(self.conns)
            ]
        else:
            self.segmen = []      # mode satu koneksi
        json.dump({"url": self.url, "size": size, "nama": self.nama,
                   "segmen": [{"idx": s.idx, "start": s.start, "end": s.end}
                              for s in self.segmen]},
                  open(self.meta_path, "w"), indent=2)

    def _ambil(self, seg: Segment):
        perlu = seg.perlu
        for percobaan in range(1, RETRY_MAKS + 1):
            # DESAIN PENTING: saat dijeda, thread worker KELUAR (return), tidak
            # menunggu pause dibersihkan. Kalau menunggu, resume akan men-spawn
            # worker baru sementara yang lama bangun lagi -> DUA penulis per
            # segmen pada file .part yang sama -> progres ngawur dan data rusak.
            if self._stop.is_set() or self._pause.is_set():
                return

            sudah = os.path.getsize(self.part(seg.idx)) if os.path.exists(self.part(seg.idx)) else 0
            if sudah >= perlu:
                return
            mulai = seg.start + sudah
            try:
                req = urllib.request.Request(
                    self.url, headers={**UA, "Range": f"bytes={mulai}-{seg.end}"})
                with urllib.request.urlopen(req, timeout=60) as r:
                    if r.status != 206:
                        raise RuntimeError(f"status {r.status}, bukan 206")
                    with open(self.part(seg.idx), "ab") as f:
                        while not self._stop.is_set():
                            if self._pause.is_set():
                                break
                            c = r.read(CHUNK)
                            if not c:
                                break
                            f.write(c)
                            f.flush()          # tanpa flush, progres di disk tertinggal
                if os.path.getsize(self.part(seg.idx)) >= perlu:
                    return
            except (urllib.error.HTTPError, urllib.error.URLError, ConnectionError,
                    TimeoutError, RuntimeError, OSError) as e:
                kode = getattr(e, "code", None)
                if kode == 416:
                    return
                if percobaan == RETRY_MAKS:
                    raise
                jeda = max(2 ** percobaan, 5) if kode == 429 else min(2 ** percobaan, 20)
                time.sleep(jeda)

    def _ambil_tunggal(self):
        """Server tanpa Range: satu stream, tetap bisa resume kalau server mengirim dari awal."""
        p = self.part(0)
        sudah = os.path.getsize(p) if os.path.exists(p) else 0
        req = urllib.request.Request(self.url, headers=UA)
        with urllib.request.urlopen(req, timeout=60) as r, open(p, "ab") as f:
            dilewati = 0
            while not self._stop.is_set():
                if self._pause.is_set():
                    break
                c = r.read(CHUNK)
                if not c:
                    break
                if dilewati < sudah:
                    c = c[sudah - dilewati:]
                    dilewati = sudah
                    if not c:
                        continue
                f.write(c)

    def _gabung(self):
        if not self.segmen:
            if self.size and os.path.getsize(self.part(0)) == self.size:
                os.replace(self.part(0), self.target)
            else:
                raise RuntimeError("ukuran tidak sesuai")
            return
        with open(self.target, "wb") as fout:
            for s in self.segmen:
                with open(self.part(s.idx), "rb") as fp:
                    while True:
                        b = fp.read(1 << 20)
                        if not b:
                            break
                        fout.write(b)
                os.remove(self.part(s.idx))
        # VERIFIKASI WAJIB: ukuran akhir harus sama persis dengan Content-Length.
        # Tanpa ini, download yang terpotong/redirect ke halaman error akan
        # dilaporkan "done" padahal filenya rusak.
        akhir = os.path.getsize(self.target)
        if self.size and akhir != self.size:
            os.remove(self.target)
            raise RuntimeError(
                f"hasil tidak utuh: {akhir} byte, seharusnya {self.size}. "
                f"Server mungkin membalas halaman error atau memotong koneksi.")
        # Hapus meta setelah selesai — folder download tetap bersih,
        # hanya berisi file hasil unduhan (tanpa file .dm.json).
        if os.path.exists(self.meta_path):
            try:
                os.remove(self.meta_path)
            except OSError:
                pass

    def _segarkan_url(self):
        """Cek apakah URL masih hidup sebelum melanjutkan download.

        Kalau server mengalihkan ke URL baru (signed URL kedaluwarsa di-refresh,
        CDN berpindah), pakai URL hasil redirect. Data .part tetap dipakai,
        jadi download lanjut dari byte terakhir — tidak mengunduh ulang.
        Kalau file di server berubah ukuran, mulai dari nol supaya tidak rusak.
        """
        try:
            size, final, _nama, _ranges = probe(self.url)
        except Exception:                          # noqa: BLE001
            return          # URL lama masih dipakai; error akan muncul wajar
        if final and final != self.url:
            self.url = final                        # URL segar
        if size and self.size and size != self.size:
            # Berkas di server berbeda -> .part lama tidak valid, mulai ulang
            for f in os.listdir(self.folder):
                if f.startswith(os.path.basename(self.target) + ".part"):
                    try:
                        os.remove(os.path.join(self.folder, f))
                    except OSError:
                        pass
            self.byte_offset = 0
            self._bytes = 0
            self.segmen = []
            self.size = None       # paksa _siapkan() membangun ulang segmen

    def run(self):
        # Cegah dua loop jalan bersamaan untuk task yang sama.
        # Tanpa ini, klik "Lanjut" saat thread lama masih menunggu pause
        # akan membuat dua worker menulis ke file .part yang sama -> data rusak.
        if not self._jalan_lock.acquire(blocking=False):
            return
        try:
            self._run_inner()
        finally:
            self._jalan_lock.release()

    def _run_inner(self):
        try:
            # === Resume cerdas ===
            # Kalau task ini punya progres sebelumnya, segarkan URL dulu
            # (ikuti redirect / signed URL baru) lalu lanjutkan dari byte
            # terakhir yang sudah ada di file .part. Data tidak diunduh ulang.
            if self.byte_offset > 0:
                self._segarkan_url()
            if not self.segmen and self.size is None:
                if self._pause.is_set():
                    self.state = "paused"
                    return
                self._siapkan()
            # pengguna bisa menekan Jeda saat fase probing; hormati itu
            if self._pause.is_set() or self._stop.is_set():
                self.state = "paused"
                return
            self.state = "running"
            self.started = self.started or time.time()

            if self.segmen:
                self._threads = [
                    threading.Thread(target=self._ambil, args=(s,), daemon=True)
                    for s in self.segmen
                ]
                for t in self._threads:
                    t.start()
                for t in self._threads:
                    while t.is_alive():
                        t.join(0.3)
            else:
                self._ambil_tunggal()

            if self._stop.is_set():
                self.state = "paused" if self._pause.is_set() else "queued"
                return

            lengkap = (all(os.path.getsize(self.part(s.idx)) >= s.perlu for s in self.segmen)
                       if self.segmen else (self.size is None or
                                            os.path.getsize(self.part(0)) >= self.size))
            if not lengkap:
                self.state = "paused"
                self.error = None
                return

            self._gabung()
            self.finished = time.time()
            self.state = "done"
        except Exception as e:                     # noqa: BLE001
            self.state = "error"
            self.error = f"{type(e).__name__}: {e}"
            # Bersihkan artefak yang tidak sempurna: .part* + .dm.json
            # File selesai (done) sudah digabung + dihapus di _gabung().
            _prefix = os.path.basename(self.target) + ".part"
            try:
                for fname in os.listdir(self.folder):
                    if fname.startswith(_prefix):
                        try:
                            os.remove(os.path.join(self.folder, fname))
                        except OSError:
                            pass
                if os.path.exists(self.meta_path):
                    os.remove(self.meta_path)
            except OSError:
                pass

    def validasi(self):
        """True kalau byte di disk sudah utuh."""
        if not self.size:
            return False
        return self.hitung() >= self.size


class Engine:
    """Kumpulan task + thread pengelola. Satu instance per proses server."""

    def __init__(self, folder):
        self.folder = folder
        os.makedirs(folder, exist_ok=True)
        self.tasks: dict[str, Task] = {}
        self._lock = threading.Lock()

    def add(self, url, nama=None, conns=8, mulai=True):
        # Dedupe: URL yang sama dan belum selesai -> pakai task yang sudah ada.
        # Tanpa ini, klik download dua kali membuat dua worker rebutan file .part yang sama.
        with self._lock:
            for t in self.tasks.values():
                if t.url == url and t.state not in ("done", "error"):
                    return t
            # JANGAN hapus task lama dari daftar. Dulu di sini ada kode yang
            # membuang riwayat URL yang sama, dan efeknya: task lama hilang
            # tanpa bisa disentuh, tombol Hapus-nya menjadi 404, dan file
            # yatim tertinggal. Task lama sekarang dibiarkan; pengguna yang
            # menentukan kapan menghapusnya.
        t = Task(url, self.folder, nama, conns)
        with self._lock:
            self.tasks[t.id] = t
        if mulai:
            threading.Thread(target=t.run, daemon=True).start()
        else:
            threading.Thread(target=self._jalankan, args=(t,), daemon=True).start()
        return t

    def add_yt(self, url, ytdlp_path, quality="best"):
        """Download via yt-dlp (YouTube, TikTok, X, dsb).
        quality: 'best', '1080', '720', '480', 'audio'"""
        t = Task(url, self.folder, nama=None, conns=1)
        with self._lock:
            self.tasks[t.id] = t
        threading.Thread(target=self._run_yt, args=(t, ytdlp_path, url, quality), daemon=True).start()
        return t

    # Format map: quality -> (yt-dlp -f string, merge?)
    # bv* = video-only, ba = best audio, /b = fallback ke best (single format).
    # /b menangani kasus progresif (video+audio) vs adaptif (pisah) otomatis.
    # YouTube HLS-only → perlu merge dengan ffmpeg untuk dapat video+audio.
    _YT_QUALITY = {
        "best":   ("bv*+ba/b", True),
        "1080":   ("bv*[height<=1080]+ba/b", True),
        "720":    ("bv*[height<=720]+ba/b", True),
        "480":    ("bv*[height<=480]+ba/b", True),
        "audio":  ("ba", False),
    }

    # Path ffmpeg — relatif terhadap file ini (portable).
    # Jika di tools/ffmpeg/bin (bundled), dipakai langsung. Tidak ada,
    # yt-dlp auto-fallback ke PATH system atau skip merge.
    _FFMPEG_REL = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tools", "ffmpeg", "bin")
    _FFMPEG_DIR = _FFMPEG_REL if os.path.isdir(_FFMPEG_REL) else None

    @staticmethod
    def _yt_bytes(s):
        """Parse '4.55MiB' / '1.2GiB' / '500KiB' → int bytes."""
        s = s.strip()
        for unit, mult in [("GiB", 1024**3), ("MiB", 1024**2), ("KiB", 1024),
                           ("GB", 10**9), ("MB", 10**6), ("KB", 10**3),
                           ("B", 1)]:
            if s.endswith(unit):
                try:
                    return int(float(s[:-len(unit)].strip()) * mult)
                except ValueError:
                    return 0
        try:
            return int(float(s))
        except ValueError:
            return 0

    def _run_yt(self, t, ytdlp_path, url, quality="best"):
        """Jalankan yt-dlp. Nama + total size didapat sebelum download
        via --skip-download --print (filesize_approx). Progres di-scan
        dari folder download agar konsisten dengan download file biasa:
        hitang() return _bytes, info() hitung persen = done/size*100."""
        t.state = "probing"
        if not os.path.isdir(self.folder):
            os.makedirs(self.folder, exist_ok=True)
        before = set(os.listdir(self.folder))

        fmt, do_merge = self._YT_QUALITY.get(quality, self._YT_QUALITY["best"])
        try:
            # --- 1. Pre-fetch: title + total size (filesize_approx) ---
            meta_cmd = [
                ytdlp_path, "--skip-download",
                "-f", fmt,
                "--no-warnings", "--no-playlist",
                "--print", "%(title)s|%(filesize_approx)s",
                url,
            ]
            if do_merge and self._FFMPEG_DIR:
                meta_cmd += ["--ffmpeg-location", self._FFMPEG_DIR]
            try:
                meta = subprocess.run(
                    meta_cmd, capture_output=True, text=True,
                    timeout=30, cwd=os.path.dirname(ytdlp_path),
                )
                if meta.returncode == 0 and meta.stdout.strip():
                    title, _, size_approx = meta.stdout.strip().rpartition("|")
                    if title:
                        ext = ".mp4" if do_merge else ".webm"
                        t.nama = _nama_aman(title.strip()) + ext
                    s = int(float(size_approx.strip()) or 0)
                    if s > 0:
                        t.size = s
            except Exception:                          # noqa: BLE001
                pass  # lanjutkan tanpa metadata

            # Fallback nama: kalau pre-fetch gagal/kosong, popup jangan stuck
            # di "pending.bin". Ambil ID video (YouTube) atau host sebagai nama.
            if t.nama in ("pending.bin", "download.bin"):
                from urllib.parse import urlparse, parse_qs
                u = urlparse(url)
                vid = parse_qs(u.query).get("v", [""])[0]
                if vid:
                    t.nama = f"video-{vid}.mp4"
                else:
                    dasar = (u.netloc or "video").split(".")[0]
                    t.nama = _nama_aman(dasar) + ".mp4"

            # --- 2. Build download command ---
            cmd = [
                ytdlp_path,
                "-o", os.path.join(self.folder, "%(title)s.%(ext)s"),
                "--no-warnings", "--no-playlist",
                "-f", fmt,
            ]
            if do_merge:
                cmd += ["--merge-output-format", "mp4"]
                if self._FFMPEG_DIR:
                    cmd += ["--ffmpeg-location", self._FFMPEG_DIR]
            cmd.append(url)

            proc = subprocess.Popen(
                cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                cwd=os.path.dirname(ytdlp_path),
            )
            t.state = "running"

            # --- 3. Scan folder untuk _bytes (progress real-time) ---
            def scan_progress():
                while proc.poll() is None:
                    try:
                        files = [f for f in os.listdir(self.folder)
                                 if not f.endswith(".dm.json")
                                 and not f.startswith(".")
                                 and f not in before]
                        if files:
                            files.sort(
                                key=lambda f: (
                                    os.path.getsize(os.path.join(self.folder, f))
                                    if os.path.isfile(os.path.join(self.folder, f))
                                    else 0
                                ),
                                reverse=True,
                            )
                            active = files[0]
                            size = os.path.getsize(os.path.join(self.folder, active))
                            if size > 0:
                                t._bytes = size
                    except OSError:
                        pass
                    time.sleep(0.5)

            threading.Thread(target=scan_progress, daemon=True).start()

            # --- 4. Wait for completion ---
            deadline = time.time() + 600
            while proc.poll() is None:
                if t._stop.is_set():
                    proc.terminate()
                    t.state = "paused"
                    return
                if time.time() > deadline:
                    proc.terminate()
                    t.state = "error"
                    t.error = "yt-dlp timeout (>10m)"
                    return
                time.sleep(0.5)

            if proc.returncode != 0:
                t.state = "error"
                t.error = f"yt-dlp exit {proc.returncode}"
                return

            # --- 5. Cari file final di folder ---
            after = set(os.listdir(self.folder))
            new_files = [
                f for f in (after - before)
                if not f.endswith(".part") and not f.endswith(".dm.json")
                and not f.startswith(".")
            ]
            if not new_files:
                t.state = "error"
                t.error = "yt-dlp selesai tapi tidak ada file baru"
                return
            new_files.sort(
                key=lambda f: os.path.getmtime(os.path.join(self.folder, f)),
                reverse=True,
            )
            t.nama = new_files[0]
            target_path = os.path.join(self.folder, t.nama)
            t.size = os.path.getsize(target_path) if os.path.exists(target_path) else 0
            t._bytes = t.size
            t.persen = 100.0
            t.state = "done"
            t.finished = time.time()
        except Exception as e:                      # noqa: BLE001
            t.state = "error"
            t.error = f"{type(e).__name__}: {e}"

    def _jalankan(self, t):
        try:
            t._siapkan()
        except Exception as e:                     # noqa: BLE001
            t.state = "error"
            t.error = str(e)
            return
        t.run()

    def get(self, tid):
        return self.tasks.get(tid)

    def semua(self):
        return [t.info() for t in sorted(self.tasks.values(), key=lambda x: x.created)]

    def hapus(self, tid, hapus_file=False):
        t = self.tasks.get(tid)
        if not t:
            return False
        t.stop()
        with self._lock:
            self.tasks.pop(tid, None)
        if hapus_file:
            # Hanya file di dalam folder download, dan hanya yang berawalan
            # nama file task ini. abspath + commonpath mencegah ../ keluar folder.
            folder_abs = os.path.abspath(self.folder)
            dasar = os.path.basename(t.target)
            for f in list(os.listdir(self.folder)):
                if not f.startswith(dasar):
                    continue
                p = os.path.abspath(os.path.join(self.folder, f))
                if os.path.commonpath([p, folder_abs]) != folder_abs:
                    continue          # jangan pernah keluar folder
                try:
                    os.remove(p)
                except OSError:
                    pass
        return True
