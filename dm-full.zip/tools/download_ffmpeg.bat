@echo off
:: Auto-download ffmpeg lite untuk merge video+audio YouTube
:: Hanya perlu jalan sekali. Hasil ekstrak ke tools\ffmpeg\bin
setlocal
set "FFMPEG_DIR=%~dp0..\tools\ffmpeg"

echo Mengunduh ffmpeg (butuh sekali saja)...
powershell -Command "Invoke-WebRequest -Uri 'https://www.gyan.dev/ffmpeg/builds/packages/ffmpeg-8.1.2-essentials_build.zip' -OutFile '%~dp0ffmpeg.zip'" 2>nul

if NOT exist "%~dp0ffmpeg.zip" (
  echo Download gagal. Coba buka manual: https://www.gyan.dev/ffmpeg/builds/packages/ffmpeg-8.1.2-essentials_build.zip
  pause
  exit /b 1
)

powershell -Command "Expand-Archive -Path '%~dp0ffmpeg.zip' -DestinationPath '%FFMPEG_DIR%\tmp' -Force" 2>nul
if NOT exist "%FFMPEG_DIR%\tmp" (
  echo Ekstrak gagal. Install 7-Zip lalu ekstrak ffmpeg.zip ke %FFMPEG_DIR%
  pause
  exit /b 1
)

move "%FFMPEG_DIR%\tmp\ffmpeg-8.1.2-essentials_build\bin\*.dll" "%FFMPEG_DIR%\bin\" >nul 2>&1
move "%FFMPEG_DIR%\tmp\ffmpeg-8.1.2-essentials_build\bin\ffmpeg.exe" "%FFMPEG_DIR%\bin\" >nul 2>&1
move "%FFMPEG_DIR%\tmp\ffmpeg-8.1.2-essentials_build\bin\ffprobe.exe" "%FFMPEG_DIR%\bin\" >nul 2>&1
rmdir /s /q "%FFMPEG_DIR%\tmp" 2>nul
del "%~dp0ffmpeg.zip" 2>nul

echo.
echo ffmpeg terpasang di: %FFMPEG_DIR%\bin
echo Sekarang YouTube 1080p/720p bisa merge video+audio.
echo Jalankan server lagi (double-click 1_JALANKAN_SERVER.bat)
pause
