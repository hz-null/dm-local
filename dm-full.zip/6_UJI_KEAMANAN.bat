import subprocess, os, shutil, time
# Jalankan audit keamanan: python uji_keamanan.py
PY = os.path.join(os.path.dirname(os.path.abspath(__file__)), "python", "python.exe")
if not os.path.exists(PY):
    import sys
    PY = sys.executable
r = subprocess.run([PY, os.path.join(os.path.dirname(os.path.abspath(__file__)), "uji_keamanan.py")])
raise SystemExit(r.returncode)
